// oracle.js

const history = [];

export function analyze(shots){

    if(shots.length === 0) return;

    const lastShot = shots[shots.length - 1];

    const zone = getZone(lastShot.x, lastShot.y);

    history.push(zone);

    updateProfile();

    predictNext();

}

function getZone(x,y){

    const width = window.innerWidth * 0.7;
    const height = window.innerHeight;

    const col = Math.floor((x / width) * 3);
    const row = Math.floor((y / height) * 3);

    const zones = [
        ["A","B","C"],
        ["D","E","F"],
        ["G","H","I"]
    ];

    return zones[row]?.[col] || "E";

}

function updateProfile(){

    const counts = {};

    history.forEach(z=>{
        counts[z] = (counts[z] || 0) + 1;
    });

    let maxZone = "";
    let maxCount = 0;

    for(const zone in counts){

        if(counts[zone] > maxCount){

            maxCount = counts[zone];
            maxZone = zone;

        }

    }

    const repetition =
        Math.round((maxCount / history.length) * 100);

    let profile = "EXPLORADOR";

    if(repetition > 60)
        profile = "PERSISTENTE";

    if(repetition > 80)
        profile = "OBSESIVO";

    document.getElementById("profile").innerText =
        profile;

}

function predictNext(){

    if(history.length < 4) return;

    const lastThree =
        history.slice(-3).join(",");

    const patterns = {};

    for(let i=0;i<history.length-3;i++){

        const key =
            history.slice(i,i+3).join(",");

        const next =
            history[i+3];

        if(!patterns[key])
            patterns[key] = {};

        patterns[key][next] =
            (patterns[key][next] || 0) + 1;

    }

    const prediction = patterns[lastThree];

    if(!prediction) return;

    let bestZone = "";
    let bestScore = 0;

    for(const zone in prediction){

        if(prediction[zone] > bestScore){

            bestScore = prediction[zone];
            bestZone = zone;

        }

    }

    addLog(
        `Pattern detected → ${bestZone}`
    );

}

function addLog(message){

    const logs =
        document.getElementById("logs");

    const line =
        document.createElement("div");

    line.innerText = message;

    logs.prepend(line);

}