export function addShot(shot){

    const ctx = canvas.getContext("2d");

    ctx.beginPath();

    ctx.arc(
        shot.x,
        shot.y,
        8,
        0,
        Math.PI*2
    );

    ctx.fillStyle="rgba(0,255,120,.3)";

    ctx.fill();

}