export function updatePhase(count){

    let phase="OBSERVATION";

    if(count>=4)
        phase="PATTERN DETECTION";

    if(count>=7)
        phase="BEHAVIORAL MODELING";

    if(count>=10)
        phase="PREDICTIVE ENGINE";

    document.getElementById("phase").innerText=phase;

}