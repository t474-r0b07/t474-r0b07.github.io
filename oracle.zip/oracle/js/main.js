import { addShot } from './heatmap.js';
import { updatePhase } from './phases.js';
import { analyze } from './oracle.js';

const canvas = document.getElementById("goalCanvas");

let shots = [];

canvas.addEventListener("click",(e)=>{

    const rect = canvas.getBoundingClientRect();

    const shot = {
        x:e.clientX - rect.left,
        y:e.clientY - rect.top,
        time:Date.now()
    };

    shots.push(shot);

    addShot(shot);

    updatePhase(shots.length);

    analyze(shots);

});